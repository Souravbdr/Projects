import { LightningElement, track, wire, api } from 'lwc';
import { refreshApex } from '@salesforce/apex';
import getPro from '@salesforce/apex/fetchPruds.getProducts';
import addOP from '@salesforce/apex/fetchPruds.addOrdPro';
import getSearchList from '@salesforce/apex/fetchPruds.searchProducts';
import getPbookEntries from '@salesforce/apex/fetchPruds.getPricebookEntries';
export default class SearchProduct extends LightningElement {
    @track columns = [
        {
            label: 'Product Name',
            fieldName: 'Name',
            type: 'text'
        },
        {
            label: 'Product Code',
            fieldName: 'ProductCode',
            type: 'text'
        },
        {
            label: 'Stock Quantity',
            fieldName: 'Stock_Quantity__c',
            type: 'number',
            cellAttributes: { alignment: 'center' }
        },
        {
            label: 'Brand',
            fieldName: 'Brand__c',
            type: 'text',
        },
    ];
    @track selColumns = [
        {
            label: 'Product Name',
            fieldName: 'Name',
            type: 'text'
        },
        {
            label: 'Partial Quantity',
            fieldName: 'Quantity',
            type: 'number',
            editable: true
        },
        {
            label: 'MRP',
            fieldName: 'UnitPrice',
            type: 'number',
            cellAttributes: { alignment: 'left' }
        },
    ];

    inp = '';
    @track products = [];
    @track pruds = [];
    @track pBookEnt = [];
    
    wiredProductsResult;

    @wire(getPro)
    wiredProducts(result) {
        this.wiredProductsResult = result;
        if (result.data) {
            this.products = result.data;
            this.pruds = result.data;
            console.log(this.products);
        }
        if (result.error)
            this.error = result.error;
    }
    @wire(getPbookEntries)
    getPbookEntData({ error, data }) {
        if (data) {
            this.pBookEnt = data;
            console.log(this.pBookEnt);
        }
        if (error)
            this.error = error;
    }

    onSearch(event) {

        this.inp = event.target.value;

        window.clearTimeout(this.delayTimeout);
        this.delayTimeout = setTimeout(() => {
            getSearchList({ keys: this.inp, li: this.pruds })
                .then(result => {
                    this.products = result;
                    console.log(this.products);
                });
        }, 300);
    }


    @track selectedProducts = [];

    @track priceBEntrId;
    @track priceBEntryMrp;
    flag = false;
    errPro = false;
    dTable = true;
    @api recordId;
    @track draftValues = [];
    @track errorProduct;
    stckQuant;
    @track rowSel = [];

    getSelectedName(event) {
        this.rowSel = event.detail.selectedRows;
    }
    @track errors;
    handleNext() {
        this.priceBEntryId;
        this.priceBEntryMrp;

        this.dTable = true;
        this.errPro = false;

        if (this.rowSel.length == 0) {
            this.errorProduct = 'Please Select some products!';
            this.errPro = true;
            this.dTable = false;
            this.flag = true;
        }
        else {
            for (let i = 0; i < this.rowSel.length; i++) {
                if (this.rowSel[i].Stock_Quantity__c < 1) {
                    this.errorProduct = 'The selected product ' + this.rowSel[i].Name + ' isunavailable!';
                    this.errPro = true;
                    this.dTable = false;
                    this.flag = true;
                    break;
                }
                for (let j = 0; j < this.pBookEnt.length; j++) {
                    if (this.pBookEnt[j].Product2Id == this.rowSel[i].Id) {
                        //console.log(this.pBookEnt[j].Product2Id + '=>' + this.rowSel[i].Id);
                        this.priceBEntryId = this.pBookEnt[j].Id;
                        this.priceBEntryMrp = this.pBookEnt[j].UnitPrice;
                        break;
                    }
                }
                this.selectedProducts[i] = {
                    Name: this.rowSel[i].Name,
                    Product2Id: this.rowSel[i].Id,
                    Quantity: "",
                    UnitPrice: this.priceBEntryMrp,
                    PricebookEntryId: this.priceBEntryId,
                    Stock_Quantity__c: this.rowSel[i].Stock_Quantity__c
                };
            }
            this.flag = true;
        }
    }
    qGreat = false;
    handleSave(event) {
        const addjson = [];
        console.log(this.selectedProducts);
        var len = this.selectedProducts.length;
        for (let i = 0; i < len; i++) {
            var quants = event.target.draftValues[i].Quantity;
            if (quants > this.selectedProducts[i].Stock_Quantity__c) {
                this.errorProduct = this.selectedProducts.Name;
                this.qGreat = true;
            }
            else {
                addjson[i] = {
                    Product2Id: this.selectedProducts[i].Product2Id,
                    Quantity: quants,
                    UnitPrice: this.selectedProducts[i].UnitPrice,
                    OrderId: this.recordId,
                    PricebookEntryId: this.selectedProducts[i].PricebookEntryId
                };
            }
        }
        console.log(addjson);
        if (this.qGreat == false) {
            addOP({ listObj: addjson })
                .then(() => {
                    this.flag = false;
                    return refreshApex(this.wiredProductsResult);
                });
        }
        
    }
    handleClose() {
        this.flag = false;
    }
    gClose() {
        this.qGreat = false;
    }



}


