import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import ORDER_OBJECT from '@salesforce/schema/Order';
import ACCOUNT_NAME from '@salesforce/schema/Order.AccountId';
import ORDER_START_DATE from '@salesforce/schema/Order.EffectiveDate';
import CONTRACT_NUMBER from '@salesforce/schema/Order.ContractId';
import STATUS from '@salesforce/schema/Order.Status';
import ORDER_TYPE from '@salesforce/schema/Order.Type';
import SHIPPING_ADDRESS from '@salesforce/schema/Order.ShippingAddress';
import BILLING_ADDRESS from '@salesforce/schema/Order.BillingAddress';
export default class OrderMang extends NavigationMixin(LightningElement){
    orderObject = ORDER_OBJECT;
    myFields = [ACCOUNT_NAME,ORDER_START_DATE,CONTRACT_NUMBER,STATUS,ORDER_TYPE,SHIPPING_ADDRESS,BILLING_ADDRESS];

    connectedCallback() {
        // Store the PageReference in a variable to use in handleClick.
        // This is a plain Javascript object that conforms to the
        // PageReference type by including 'type' and 'attributes' properties.
        // The 'state' property is optional.
        this.orderHomePageRef = {
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Order',
                actionName: 'home'
            },
            state: {
                // 'filterName' is a property on the page 'state'
                // and identifies the target list view.
                // It may also be an 18 character list view id.
                filterName: '00B2x00000216ewEAA' // or by 18 char '00BT0000002TONQMA4'
            }
        };
        this[NavigationMixin.GenerateUrl](this.orderHomePageRef)
            .then(url => this.url = url);
    }

    handleOrderCreated(){
        // Run code when account is created.
        this[NavigationMixin.Navigate](this.orderHomePageRef);
        
    }
    handleCancel(){
        
        this[NavigationMixin.Navigate](this.orderHomePageRef);

    }

}