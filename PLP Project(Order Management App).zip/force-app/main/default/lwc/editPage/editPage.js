import { LightningElement, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
export default class EditPage extends NavigationMixin(LightningElement) {
    @api recordId;
    connectedCallback() {
        this.orderHomePageRef = {
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Order',
                actionName: 'home'
            },
            state: {
                filterName: '00B2x00000216ewEAA'
            }
        };
        this[NavigationMixin.GenerateUrl](this.orderHomePageRef)
            .then(url => this.url = url);
    }
    flag = false;
    handleSubmit(event) {
        event.preventDefault();
        if(event.detail.fields.Status == 'Cancelled'){
            
            if(event.detail.fields.Remarks__c == "" || event.detail.fields.Remarks__c == null){
                this.flag = true;
            }
            else{
                this.template.querySelector('lightning-record-edit-form').submit(event.detail.fields);
            }
        }
        else{
            this.template.querySelector('lightning-record-edit-form').submit(event.detail.fields);
        }
 
    }
    handleSuccess() {
        this[NavigationMixin.Navigate](this.orderHomePageRef);
    }
    handleClose(){
        this[NavigationMixin.Navigate](this.orderHomePageRef);
    }
   
}