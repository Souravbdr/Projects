import { LightningElement,api, track } from 'lwc';
import getApp from '@salesforce/apex/submitApproval.getApproval';
import approval from '@salesforce/apex/submitApproval.sendApproval';
import statCancel from '@salesforce/apex/submitApproval.statusCancel';
export default class RecordView extends LightningElement {
    @api recordId;
    @track btnCancel = false;
    @track btnConfirm = false;
    connectedCallback(){
        getApp({ordId:this.recordId})
            .then(result=>{
                if(result){
                    this.btnConfirm = true;
                    this.btnCancel = true;
                }
            });
    }
    remarks;
    flag = false;
    rem(event){
        this.remarks = event.target.value;
    }
    confirmOrder(){   
        this.btnConfirm = true;
        approval({ ordId:this.recordId });
        window.location.reload();
    }
    cancel(){
        this.flag = true;
    }
    onClose(){
        this.flag = false;
    }
    cancelOrder(){
        this.btnConfirm = true;
        this.btnCancel = true;
        statCancel({ ordId:this.recordId , rem:this.remarks});
        window.location.reload();
    }
}