import { LightningElement,api } from 'lwc';

export default class OrdproView extends LightningElement {
    @api recordId;
    
}