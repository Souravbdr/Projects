import { LightningElement, wire,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
import { deleteRecord } from 'lightning/uiRecordApi';
import getOrderItem from '@salesforce/apex/OrderItemController.getOrderItemList';
//import { reduceErrors } from 'c/ldsUtils';

export default class OrdItemListView extends LightningElement {
    orderItems;
    error;
    @api recordId;
    /** Wired Apex result so it can be refreshed programmatically */
    wiredorderItemsResult;

    @wire( getOrderItem , { ordId:'$recordId' } )
    wiredorderItems(result) {
        this.wiredorderItemsResult = result;
        console.log(this.recordId);
        console.log(this.wiredorderItemsResult);
        if (result.data) {
            this.orderItems = result.data;
            this.error = undefined;
        } else if (result.error) {
            this.error = result.error;
            this.orderItems = undefined;
        }
    }

    deleteoOrderItem(event) {
        const recordId = event.target.dataset.recordid;
        deleteRecord(recordId)
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Order deleted',
                        variant: 'success'
                    })
                );
                return refreshApex(this.wiredorderItemsResult);
            })
            .catch((error) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error deleting record',
                        message: error,
                        variant: 'error'
                    })
                );
            });
    }
}